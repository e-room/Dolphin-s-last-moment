/**
 * Copyright (c) 2022 ZEP Co., LTD
 */
App.showCenterLabel("Hello World");
let zepLogo = App.loadSpritesheet("zep_logo.png");
Map.putObject(0, 0, zepLogo, {
  overlap: true
});
App.onDestroy.Add(function () {
  Map.clearAllObjects();
}); // Player

App.onObjectAttacked.Add(function (sender, x, y) {
  App.showCenterLabel(`${sender.name}님이 좌표: (${x}, ${y}) 에서 쓰레기를 공격!!`);
}); // Trash object

let trash = App.loadSpritesheet("trash.png");
App.onStart.Add(function () {
  Map.putObject(5, 5, trash, {
    overlap: true
  });
  Map.putObject(10, 10, trash, {
    overlap: true
  });
  Map.putObject(20, 20, trash, {
    overlap: true
  });
});